﻿//Usings
using System.ComponentModel.DataAnnotations;


namespace Ejercicio1.Models.DataModels
{
    public class BaseEntity
    {

        [Required]
        [Key]
        public int Id { get; set; }
        [Required, StringLength(280)]
        public string Descripción_Corta { get; set; } = string.Empty;
        public string Descripción_Larga { get; set; } = string.Empty;
        public string Objetivos { get; set; } = string.Empty;
        public string Requisitos { get; set; } = string.Empty;

        public enum Nivel
        {
            Principiante,
            Intermedio,
            Avanzado
        }  
    }
}
