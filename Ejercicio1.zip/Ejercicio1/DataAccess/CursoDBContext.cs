﻿using Ejercicio1.Models.DataModels;
using Microsoft.EntityFrameworkCore;

namespace Ejercicio1.DataAccess
{
    public class CursoDBContext: DbContext
    {
        public CursoDBContext(DbContextOptions<CursoDBContext> options): base(options) 
        { 
        }

        //Add tables

        public DbSet<Students>? students { get; set; } //

    }
}
