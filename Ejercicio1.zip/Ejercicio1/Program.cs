//Using
using Microsoft.EntityFrameworkCore;
using Ejercicio1.DataAccess;

var builder = WebApplication.CreateBuilder(args);


//Conection SqlServer

const string CONNECTIONNAME = "Curso";
var connectionString = builder.Configuration.GetConnectionString(CONNECTIONNAME); 

//Add context to services of builders

builder.Services.AddDbContext<CursoDBContext>(options => options.UseSqlServer(connectionString));

// Add services to the container.

builder.Services.AddControllers();
// Learn more about configuring Swagger/OpenAPI at https://aka.ms/aspnetcore/swashbuckle
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();

var app = builder.Build();

// Configure the HTTP request pipeline.
if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

app.UseHttpsRedirection();

app.UseAuthorization();

app.MapControllers();

app.Run();
